from kelinci import *
from telethon import events, Button
import requests

url = "https://raw.githubusercontent.com/V3SAKURAAIRIV3/BotDejavuV3/main/status-today"

response = requests.get(url)


if response.status_code == 200:
    print(response.text)
else:
    print("Gagal mendapatkan konten dari URL")

@bot.on(events.NewMessage(pattern=r"(?:.menu|/start|/menu)$"))
@bot.on(events.CallbackQuery(data=b'menu'))
async def start_menu(event):
    user_id = str(event.sender_id)

    if check_user_registration(user_id):
        try:
            saldo_aji, level = get_saldo_and_level_from_db(user_id)

            if level == "user":
                member_inline = [
                    [Button.inline("❤️ SSH  ❤️", "ssh")],
                    [Button.inline("❤️ VMESS ❤️", "vmess-member"),
                     Button.inline("❤️ VLESS ❤️", "vless-member")],
                    [Button.inline("❤️ TROJAN ❤️", "trojan-member"),
                     Button.inline("❤️ SHADOWSOCKS ❤️", "shadowsocks-member")],
                    [Button.inline("❤️ NOOBZVPN ❤️", "noobzvpn-member")],
                    [Button.inline("❤️ INFO PORT ❤️", "info")]
                ]

                member_msg = f"""
**━━━━━━━━━━━━━━━━━━**
**❤️ AUTOSCRIPT PREMIUM 2024 ❤️
**━━━━━━━━━━━━━━━━━━**
**❤️ INFORMATION ❤️ : {response.text}**
**━━━━━━━━━━━━━━━━━━**
**❤️ STATUS RUNNING ❤️ **
**❤️ SSH:** `{get_ssh_status()}`
**❤️ XRAY:** `{get_xray_status()}`
**❤️ UDP:** `{get_udp_status()}`
**❤️ DNS:** `{get_slowdns_status()}`
**❤️ BEAR:** `{get_dropbear_status()}`
**❤️ WS:** `{get_ws_status()}`
**❤️ NOOB:** `{get_noobz_status()}`
**❤️ DDOS:** `{get_ddos_status()}`
**━━━━━━━━━━━━━━━━━━**
**❤️ Recode by @SakuraAiriV3 **
**❤️ Version:** `2024`
**❤️ Your ID:** `{user_id}`
**❤️ Total Coin: ** `{saldo_aji}`
"""
                x = await event.edit(member_msg, buttons=member_inline)
                if not x:
                    await event.reply(member_msg, buttons=member_inline)


            elif level == "admin":
                admin_inline = [
                    [Button.inline("❤️ SSH ❤️", "ssh")],
                    [Button.inline("❤️ VMESS ❤️", "vmess"),
                     Button.inline("❤️ VLESS ❤️", "vless")],
                    [Button.inline("❤️ TROJAN ❤️", "trojan"),
                     Button.inline("❤️ SHADOWSOCKS ❤️", "shadowsocks")],
                    [Button.inline("❤️ NOOBZVPN ❤️", "noobzvpns")],
                     [Button.inline("❤️ ADD MEMBER ❤️", "registrasi-member"),
                     Button.inline("❤️ DELETE MEMBER ❤️", "delete-member")],
                    [Button.inline("❤️ SHOW MEMBER ❤️", "show-user"),
                    Button.inline("❤️ + COIN MEMBER ❤️", "addsaldo")],
                    [Button.inline("❤️ INFO PORT ❤️", "info"),
                     Button.inline("❤️ PANEL SETTING ❤️", "setting")]
                ]

                admin_msg = f"""
**━━━━━━━━━━━━━━━━━━**
**❤️ AUTOSCRIPT PREMIUM 2024 ❤️
**━━━━━━━━━━━━━━━━━━**
**❤️ INFORMATION ❤️ : {response.text}**
**━━━━━━━━━━━━━━━━━━**
**❤️ STATUS RUNNING ❤️ **
**❤️ SSH:** `{get_ssh_status()}`
**❤️ XRAY:** `{get_xray_status()}`
**❤️ UDP:** `{get_udp_status()}`
**❤️ DNS:** `{get_slowdns_status()}`
**❤️ BEAR:** `{get_dropbear_status()}`
**❤️ WS:** `{get_ws_status()}`
**❤️ NOOB:** `{get_noobz_status()}`
**❤️ DDOS:** `{get_ddos_status()}`
**━━━━━━━━━━━━━━━━━━**
**❤️ Recode by @SakuraAiriV3 **
**❤️ Version:** `2024`
**❤️ Your ID:** `{user_id}`
**❤️ Total User:** `{get_user_count()}`
**━━━━━━━━━━━━━━━━━━**
"""
                x = await event.edit(admin_msg, buttons=admin_inline)
                if not x:
                    await event.reply(admin_msg, buttons=admin_inline)

        except Exception as e:
            print(f"Error: {e}")

    else:
        await event.reply(
            f'```Anda Belum Register, Silahkan Register```',
            buttons=[[(Button.inline("Register", "registrasi"))]]
        )

